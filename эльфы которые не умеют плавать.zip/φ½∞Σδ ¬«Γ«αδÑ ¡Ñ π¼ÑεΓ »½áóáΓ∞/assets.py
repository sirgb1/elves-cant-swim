import pygame as pg
pg.init()
# idle = pg.image.load('assets/idle/1.png')

idle_right = [
    pg.image.load('assets/idle_right/1.png'),
    pg.image.load('assets/idle_right/2.png'),
    pg.image.load('assets/idle_right/3.png'),
    pg.image.load('assets/idle_right/4.png')
]

idle_left = [
    pg.image.load('assets/idle_left/1.png'),
    pg.image.load('assets/idle_left/2.png'),
    pg.image.load('assets/idle_left/3.png'),
    pg.image.load('assets/idle_left/4.png')
]

walk_right = [
    pg.image.load('assets/walk_right/1.png'),
    pg.image.load('assets/walk_right/2.png'),
    pg.image.load('assets/walk_right/3.png'),
    pg.image.load('assets/walk_right/4.png'),
    pg.image.load('assets/walk_right/5.png'),
    pg.image.load('assets/walk_right/6.png'),
    pg.image.load('assets/walk_right/7.png'),
    pg.image.load('assets/walk_right/8.png'),
]

walk_left = [
    pg.image.load('assets/walk_left/1.png'),
    pg.image.load('assets/walk_left/2.png'),
    pg.image.load('assets/walk_left/3.png'),
    pg.image.load('assets/walk_left/4.png'),
    pg.image.load('assets/walk_left/5.png'),
    pg.image.load('assets/walk_left/6.png'),
    pg.image.load('assets/walk_left/7.png'),
    pg.image.load('assets/walk_left/8.png'),
]

jump = [
    pg.image.load('assets/jump/1.png'),
    pg.image.load('assets/jump/2.png'),
    pg.image.load('assets/jump/3.png'),
    pg.image.load('assets/jump/4.png'),
    pg.image.load('assets/jump/5.png'),
    pg.image.load('assets/jump/6.png'),
    pg.image.load('assets/jump/7.png'),
    pg.image.load('assets/jump/8.png'),
    pg.image.load('assets/jump/9.png'),
    pg.image.load('assets/jump/10.png'),
    pg.image.load('assets/jump/11.png'),
]

background = pg.image.load('assets/background.jpg')
background = pg.transform.scale(background, (1400, 600))

water = pg.transform.scale(pg.image.load('assets/water/water3.png'), (90, 90))