import pygame as pg
import assets
pg.init()

class Player(pg.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()

        self.idle_right = assets.idle_right
        self.idle_left = assets.idle_left
        self.walk_right = assets.walk_right
        self.walk_left = assets.walk_left
        self.jump = assets.jump
        self.x = x
        self.y = y
        self.speed = 5

        self.image = self.idle_right[0]
        self.rect = self.image.get_rect()
        # self.rect.center = (400, 300)
        self.action = 'idle' 
        self.frame_index = 0 
        self.idle_index = 0

        self.is_jumping = False
        self.is_walking = False
        # self.walk_index = 0
        # self.jump_index = 0

    def update(self):
        if self.action == 'jump':
            # self.frame_index = 0  
            self.image = self.jump[self.frame_index]
            self.frame_index = (self.frame_index + 1) % len(self.jump)
        elif self.action == 'walk right':
            # self.frame_index = 0  
            self.image = self.walk_right[self.frame_index]
            self.frame_index = (self.frame_index + 1) % len(self.walk_right)
        elif self.action == 'walk left':
            # self.frame_index = 0  
            self.image = self.walk_left[self.frame_index]
            self.frame_index = (self.frame_index + 1) % len(self.walk_left)
        elif self.action == 'idle right':
            # self.action = 'idle right'
            self.image = self.idle_right[self.idle_index]
            self.frame_index = (self.idle_index + 1) % len(self.idle_right)
        elif self.action == 'idle left':
            self.image = self.idle_left[self.idle_index]
            self.frame_index = (self.idle_index + 1) % len(self.idle_left)
    
    def check_collision(self, puddle_coors):
        if self.x in puddle_coors:
            print('gndnsgjdkf')

    # def change_action(self, action):
    #     if action != self.action:
    #         self.action = action
    #         self.frame_index = 0

    # def animate(self):
    #     if self.action == "jump" or self.action == "walk":
    #         self.frame_index += 1
    #         if self.frame_index >= len(self.jump) or self.frame_index >= len(self.walk):
    #             self.frame_index = 0


class Puddle():
    def __init__(self, x, y):
        self.x = x
        self.y = y