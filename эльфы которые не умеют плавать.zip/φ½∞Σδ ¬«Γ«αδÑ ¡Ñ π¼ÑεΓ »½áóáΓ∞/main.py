import pygame as pg
import assets
import classes
import random

# настраиваем окно
pg.init()
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
ONE_THIRD_WIDTH = SCREEN_WIDTH // 3
screen = pg.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pg.display.set_caption('Elves can\'t swim')
background = assets.background
background_x = 0
background_y = 0

# ground
ground_y = 500

# puddle random location
puddles = []
puddle_coors = []
for i in range(5):
    puddle_x = random.randint(50, 1400)
    puddle = classes.Puddle(puddle_x, ground_y + 45)
    puddles.append(puddle)
    puddle_coors.append(puddle_x)

# sound
sound = pg.mixer.Sound('assets/bg_sound.mp3')
sound.play()

# player
player = classes.Player(20, ground_y)

# основной цикл игры
running = True
clock = pg.time.Clock()
while running:
    screen.blit(background, (background_x, background_y))
    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False
            pg.quit()
            

    keys = pg.key.get_pressed()
    if keys[pg.K_LEFT]:
        if player.x > -50:
            if player.x > ONE_THIRD_WIDTH and player.x < ONE_THIRD_WIDTH * 2:
                if background_x < 0:
                    last_key = pg.K_LEFT
                    background_x += player.speed 
                    player.action = 'walk left'
                else:
                    last_key = pg.K_RIGHT
                    player.x -= player.speed 
                    player.action = 'walk left'
            else:
                last_key = pg.K_LEFT
                player.x -= player.speed
                player.action = 'walk left'
    elif keys[pg.K_RIGHT]:
        if player.x <= SCREEN_WIDTH - 50:
            if player.x > ONE_THIRD_WIDTH and player.x < ONE_THIRD_WIDTH * 2:
                if background_x > -ONE_THIRD_WIDTH:
                    last_key = pg.K_RIGHT
                    background_x -= player.speed 
                    player.action = 'walk right'
                else:
                    last_key = pg.K_RIGHT
                    player.x += player.speed 
                    player.action = 'walk right'
            else:
                last_key = pg.K_RIGHT
                player.x += player.speed 
                player.action = 'walk right'
    elif event.type == pg.KEYUP:
        if last_key == pg.K_LEFT:
            player.action = 'idle left'
        elif last_key == pg.K_RIGHT:
            player.action = 'idle right'
        else:
            player.action = 'idle right'
        if keys[pg.K_SPACE]:
            player.action = 'jump'

    # Обновление экрана
    player.update()
    player.check_collision(puddles)
    screen.blit(player.image, (player.x, player.y))
    for puddle in puddles:
        # screen.blit(assets.water, (puddle.x, ground_y + 70))
        background.blit(assets.water, (puddle.x, puddle.y))
    pg.display.update()
    # pg.display.flip()
    clock.tick(10)