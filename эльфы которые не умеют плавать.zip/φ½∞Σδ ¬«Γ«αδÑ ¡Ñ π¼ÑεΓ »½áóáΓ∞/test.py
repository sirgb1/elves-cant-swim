import pygame 
pygame.init()
screen = pygame.display.set_mode((600, 300), flags=pygame.NOFRAME)
pygame.display.set_caption('Elves cant fly')
icon = pygame.image.load('iconElves.jpg')
pygame.display.set_icon(icon)

myfont = pygame.font.Font('Beyond Wonderland.ttf', 40)
text_surface = myfont.render('Elves that can\'t swim', False, 'Green')
player = pygame.image.load('iconElves.jpg')

square = pygame.Surface((50,170))
square.fill('red')

running = True
while running:

    screen.blit(square,(100,0))
    pygame.draw.circle(square,'Green',(250,150),30)
    pygame.draw.rect(screen,'Cyan',(100,20,100,135),6)
    screen.blit(text_surface, (150, 50))
    # screen.blit(player, (100, 50))

    pygame.display.update()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a:
                screen.fill((70, 44, 133))