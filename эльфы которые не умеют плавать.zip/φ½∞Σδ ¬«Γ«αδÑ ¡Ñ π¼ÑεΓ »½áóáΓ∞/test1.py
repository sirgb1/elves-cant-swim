import pygame as pg

clock = pg.time.Clock()

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

def get_image(sheet, width, height):
    image = pg.Surface((width, height)).convert_alpha()

    return image

# задаём окно
pg.init()
screen = pg.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pg.display.set_caption('Elves cant fly')
icon = pg.image.load('assets/iconElves.jpg')
pg.display.set_icon(icon)

# импорт игрока и бэкграунда
player = pg.image.load('assets/idleleft.png')
player = pg.transform.scale(player, (50, 50))
player.set_colorkey((255, 255, 255))
bg = pg.image.load('assets/background.jpg')
bg = pg.transform.scale(bg, (SCREEN_WIDTH, SCREEN_HEIGHT))

# ходьба
walk_right = [
    pg.image.load('assets/walkright/tile000.png'),
    pg.image.load('assets/walkright/tile001.png'),
    pg.image.load('assets/walkright/tile002.png'),
    pg.image.load('assets/walkright/tile003.png'),
    pg.image.load('assets/walkright/tile004.png'),
    pg.image.load('assets/walkright/tile005.png'),
    pg.image.load('assets/walkright/tile006.png'),
    pg.image.load('assets/walkright/tile007.png'),
    pg.image.load('assets/walkright/tile008.png'),
    pg.image.load('assets/walkright/tile009.png'),
    pg.image.load('assets/idleright.png')
]

walk_left = [
    pg.image.load('assets/walkleft/tile000.png'),
    pg.image.load('assets/walkleft/tile001.png'),
    pg.image.load('assets/walkleft/tile002.png'),
    pg.image.load('assets/walkleft/tile003.png'),
    pg.image.load('assets/walkleft/tile004.png'),
    pg.image.load('assets/walkleft/tile005.png'),
    pg.image.load('assets/walkleft/tile006.png'),
    pg.image.load('assets/walkleft/tile007.png'),
    pg.image.load('assets/walkleft/tile008.png'),
    pg.image.load('assets/walkleft/tile009.png'),
    pg.image.load('assets/idleleft.png')
]

# ground
ground = pg.image.load('assets/ground.jpg')
ground = pg.transform.scale(ground, (SCREEN_WIDTH*2, 100))

# movement
idle = pg.image.load('assets/idleleft.png')

player_anim_count = 0
bg_x = 0
gr_x = 0

player_speed = 10
player_x = SCREEN_WIDTH // 2
player_y = SCREEN_HEIGHT - ground.get_height() - player.get_height() - 23

# jump
is_jump = False
jump_count = 7

# sound
bg_sound = pg.mixer.Sound('assets/music.mp3')
bg_sound.play()


running = True
while running:

    screen.blit(bg, (bg_x, 0))
    screen.blit(bg, (bg_x + SCREEN_WIDTH, 0))
    screen.blit(walk_right[10], (player_x, player_y))
    screen.blit(ground, (gr_x, SCREEN_HEIGHT - ground.get_height()))


    bg_x -= 5
    if bg_x == -SCREEN_WIDTH:
        bg_x = 0

    gr_x -= 5
    if gr_x == -SCREEN_WIDTH:
        gr_x = 0

    keys = pg.key.get_pressed()
    if keys[pg.K_LEFT] and player_x > 0:
        screen.blit(walk_left[player_anim_count], (player_x, player_y))
        player_x -= player_speed
    elif keys[pg.K_RIGHT] and player_x < SCREEN_WIDTH - player.get_height():
        screen.blit(walk_right[player_anim_count], (player_x, player_y))
        player_x += player_speed 

    # проверка прыжка
    if not is_jump:
        if keys[pg.K_SPACE]:
            is_jump = True
    else: 
        if jump_count >= -7: 
            if jump_count > 0:
                player_y -= (jump_count ** 2) / 2
            else:
                player_y += (jump_count ** 2) / 2
            jump_count -= 1

        else:
            is_jump = False
            jump_count = 7

    if player_anim_count == 9:
        player_anim_count = 0
    else: 
        player_anim_count += 1

    pg.display.update()
     
    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False
            pg.quit()

    clock.tick(20)